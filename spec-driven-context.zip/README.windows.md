# TODO API (Windows向けセットアップガイド)

この README は Windows 環境で `todo-api` を動かすための手順をまとめています。macOS / Linux の手順は既存の `README.md` を参照してください。

---

## 0. 前提ソフトウェア
- Windows 11 (仮想化機能と WSL 2 が有効)
- Docker Desktop for Windows (WSL 2 backend を有効化)
- PowerShell 7 以上 (`pwsh`)
- Python 3.11 以上と `pip`
- Git (任意: Podman Desktop + `podman-compose`)

## 1. ディレクトリと環境ファイル
```powershell
$ROOT = "D:\todo-manage"
$API  = Join-Path $ROOT "todo-api"
Set-Location $API
Copy-Item env.example .env -Force -ErrorAction SilentlyContinue
```
`.env` でポートや DB 設定をカスタマイズできます。既定では SQLite を利用します。

## 2. Claude Skills / Codex Agents の配置
```powershell
$SKILLS = Join-Path $ROOT "todo-api-skills"
$TARGET = Join-Path $API ".claude\skills"

New-Item -ItemType Directory -Force $TARGET | Out-Null

"api.task-listing.minimal-v1",
"architecture.id-allocation.counters-v1",
"ops.review.evidence-v1",
"tdd.red-case.write-v1" | ForEach-Object {
    Copy-Item -Recurse -Force (Join-Path $SKILLS $_) $TARGET
}

Copy-Item -Force (Join-Path $SKILLS "AGENTS.md") (Join-Path $API "AGENTS.md")
```
Claude Code で `todo-api` を開き、`/.claude/skills` に 4 つの Skill が並べば準備完了です。

## 3. Docker Compose で起動
```powershell
Set-Location $API
docker compose up -d          # 初回は数分かかる場合があります
docker compose logs -f todo-api
```
停止するときは `docker compose down`。データを破棄する場合は `docker compose down -v`。

## 4. ローカル (venv) で直接起動
```powershell
Set-Location $API
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -e .
alembic upgrade head
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
`Ctrl+C` で停止します。再実行時は仮想環境を有効化するだけで構いません。

## 5. Podman スクリプト
PowerShell から以下のスクリプトで Podman 環境を操作できます。
```powershell
Set-Location $API
.\start-podman.ps1   # Podman + podman-compose で起動
.\test-podman.ps1    # pytest
.\stop-podman.ps1    # 停止とクリーンアップ
```
Podman Desktop では共有ドライブと 8000 番ポートの許可設定を忘れずに行ってください。

## 6. 動作確認 (PowerShell)
```powershell
$ApiUrl = "http://localhost:8000"

Invoke-RestMethod -Uri $ApiUrl -Method Get
# => @{message=TODO API Ready}

$req = @{ title = "要件: 認証まわり"; description = "ログイン API" } | ConvertTo-Json
Invoke-RestMethod -Uri "$ApiUrl/tasks/requirements/" -Method Post \
    -ContentType "application/json" -Body $req
```
`curl.exe` を使う場合は PowerShell の alias 衝突を避けるために拡張子付きで呼び出してください。

## 7. テスト実行
```powershell
# コンテナ内で pytest
docker compose exec todo-api python -m pytest tests -v

# ローカル仮想環境
.\.venv\Scripts\Activate.ps1
python -m pytest tests -v
```
`PYTHONPATH=.` や `.env` の差異に注意し、CI と同じ条件でテストしてください。

## 8. 便利コマンド
- `docker compose logs -f todo-api` : API ログ追跡
- `docker compose exec todo-api alembic current` : DB バージョン確認
- `docker compose exec todo-api python -m app.scripts.seed` : サンプルデータ投入 (スクリプトがある場合)

---

## ディレクトリ概要
```
todo-api
├─ app/                # FastAPI アプリケーション
├─ migrations/         # Alembic スクリプト
├─ scripts/            # CLI / Podman 補助
├─ docker-compose.yml
├─ podman-compose.yml
├─ start-podman.ps1 / stop-podman.ps1 / test-podman.ps1
└─ README.windows.md
```

---

## トラブルシューティング
- Docker Desktop > Settings > Resources > WSL Integration で使用中ディストリを有効化する。
- PowerShell の実行ポリシーでスクリプトが止まる場合は `Set-ExecutionPolicy -Scope Process RemoteSigned` を一時的に実行する。
- 8000 番ポートを他プロセスが占有していないか `netstat -ano | findstr 8000` で確認する。

最終更新: 2025-10-24


